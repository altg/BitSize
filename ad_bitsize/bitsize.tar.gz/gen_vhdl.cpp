// $Author: amag97 $
// $Id: gen_vhdl.cpp,v 1.1 2006/02/17 18:14:55 amag97 Exp $


#include "bitsize_pass.h"

VHDLGen::VHDLGen(DAG *_dag , NodeSchedular *_node_sched ):BitSizePass(_dag),node_sched(_node_sched){}


void VHDLGen::operator()( string inputfile_name , ostream &os )
{
 

  process_signal();

  update_edges_bw( inputfile_name );

  gen_struct_sec();

  gen_entity_sec();

  gen_arch_sec();

  gen_components();

  output_code( os );
  

}


void VHDLGen::output_code( ostream &os ){

  os << "LIBRARY ieee;\n";   
  os << "USE ieee.std_logic_1164.ALL;\n";   
  os << "USE ieee.std_logic_arith.ALL;\n\n";   


  os << entity_code.str() << endl;

  
  os << arch_code.str() << endl;

  os << comp_code.str() << endl;

  os << struct_code.str() << endl;
  

}


void VHDLGen::do_vhdlgen()
{
  
   _DBOUT( "Doing VHDL code generation" );

   node_sched->sort_schedule();

  vector< NodeSchedular::node_vec_type >::iterator sch_itr; 
  vector< dag_index >::iterator n_itr2;

  int ctr = 0;
  for ( sch_itr = node_sched->schedule.begin() ; sch_itr != node_sched->schedule.end() ;  sch_itr++ )
    {

     
      
      for( n_itr2 = (*sch_itr).begin() ; n_itr2 != (*sch_itr).end() ; n_itr2++ )
	{

	    do_vhdlgen_node((*n_itr2));

	}  




    }



}


void VHDLGen::do_vhdlgen_node( dag_index node_num )
{

  Node* CNode = c_dag->node_vec[ node_num ];
 

  switch( CNode->node_type )
    {

   
    case ADD: gen_add_node( CNode ); break;


    case SUB: gen_sub_node( CNode ); break;


    case MUL: gen_mul_node( CNode ); break;

    case DIV: gen_div_node( CNode ); break;

    case CONSTANT: gen_const_node( CNode ); break;
   
    case OUTPUT : gen_output_node( CNode ); break;

    case INPUT : gen_input_node( CNode ); break;

    case SHIFTL : gen_shiftl_node( CNode ); break;

    case SHIFTR : gen_shiftr_node( CNode ); break;

    defualt:;



    }


}


bool VHDLGen::is_output_edge( Edge *CEdge )
{

  Node* dst_node = c_dag->node_vec[ CEdge->get_dst_node() ];
 
  return (  dst_node->node_type == OUTPUT ? true : false ); 

}

bool VHDLGen::is_input_edge( Edge *CEdge )
{

  Node* src_node = c_dag->node_vec[ CEdge->get_src_node() ];
 
  return (  src_node->node_type == INPUT ? true : false ); 

}


void VHDLGen::process_signal()
{

  string signal_name;

  string var_name;

  

 for( vector<Edge *>::iterator e_itr = c_dag->edge_vec.begin(); e_itr != c_dag->edge_vec.end();e_itr++)
    {
	
      if ( is_input_edge( (*e_itr) ) ){
	
	
	signal_name = (*e_itr)->edge_name;

	input_signals.push_back( (*e_itr) );

	signal_type[ (*e_itr) ] = INPUT_SIG;

      }
      else if ( is_output_edge( (*e_itr) ) ){

	signal_name = (*e_itr)->edge_name;

	output_signals.push_back( (*e_itr) );

	signal_type[ (*e_itr) ] = OUTPUT_SIG;


      }
      else
      {
	
	signal_name = "sig_" + (*e_itr)->edge_name;

	//internal_signals.push_back( (*e_itr) ); 

	//signal_type[ (*e_itr) ] = INTERNAL_SIG;

      }


      signal_names[ (*e_itr) ] = signal_name;

      
      if ( HWfix *c_var = dynamic_cast<HWfix *>( (*e_itr)->my_var ) )
	{
	  varnames_map[ c_var->var_name ] = (*e_itr);
	  
	}

    }



}


// string VHDLGen::get_signal_name( Edge* CEdge ){

//   if ( is_input_edge( CEdge ) ){
	
	
//         return input_signals[ CEdge ]; 

//       }
//       else if ( is_output_edge( CEdge ) ){

	

// 	return output_signals[ CEdge ];


//       }
//       else
//       {
	
// 	return internal_signals[ CEdge ]; 


//       }
  



// }

void VHDLGen::add_internal_signal( Edge *CEdge ){

  if ( !is_output_edge( CEdge ) && !is_input_edge( CEdge ) )
    {

      internal_signals.push_back( CEdge ); 

      signal_type[ CEdge ] = INTERNAL_SIG;

    }

}


void VHDLGen::gen_add_node(  Node * CNode )
{
 

  Edge *l_edge, *r_edge, *out_edge;

  
  l_edge = c_dag->edge_vec[ CNode->in_edges[0] ];
  r_edge = c_dag->edge_vec[ CNode->in_edges[1] ];
  out_edge = c_dag->edge_vec[ CNode->out_edges.back() ];
  
  add_internal_signal( out_edge );

  int bw_a = (edge_bwdata[l_edge])->total_bw;
  int bw_b = (edge_bwdata[r_edge])->total_bw;

  int bw_out  = (edge_bwdata[out_edge])->total_bw;


  int comp_out_bw = max( bw_a , bw_b ) + 1;

  stringstream comp_name;
  comp_name << "add_" << bw_a << "x" << bw_b;

  string outtemp_sig_name( "tmp_" + CNode->node_name );
  //outtemp_sig_name << "tmp_" << CNode->node_name;

  sig_dec << "\tsignal " << outtemp_sig_name << " : ";

  sig_dec << "std_logic_vector( " << comp_out_bw << " - 1 downto 0 ) := ( others => '0' );\n";
  
  struct_code << endl << "-- Add Node  " << endl;


  struct_code << CNode->node_name << ": " << comp_name.str() << endl;

  struct_code << "port map ( " << endl;

  struct_code << "a => " << signal_names[ l_edge ] << ","<< endl;
  struct_code << "b => " << signal_names[ r_edge ] << ","<< endl;

  struct_code << "s => " << outtemp_sig_name << endl;

 
  struct_code << ");\n\n";

  struct_code << signal_names[ out_edge ] << " <= " << outtemp_sig_name;
  

  adjust_signal_bw( comp_out_bw , bw_out , CNode->node_name );
  
 
  struct_code << ";\n\n";
  
  comp_table[ comp_name.str() ] = new COMP_TYPE( bw_a , bw_b , false , comp_out_bw , ADD_COMP );  //comp_data;

  

}

void VHDLGen::adjust_signal_bw(int comp_out_bw , int bw_out , string node_name )
{

 if ( comp_out_bw > bw_out ){

    struct_code << "( " << comp_out_bw << " - 1 downto ";

    struct_code << comp_out_bw - bw_out;

    struct_code << ")";

  }
  else if ( comp_out_bw < bw_out ){ 


    struct_code << "&";

    string outtemp_sig_dummy_name( "tmp_" + node_name + "_dummy" );

    struct_code << outtemp_sig_dummy_name; 

    sig_dec << "\tsignal " << outtemp_sig_dummy_name << " : ";

    sig_dec << "std_logic_vector( " << bw_out - comp_out_bw << " - 1 downto 0 ) := ( others => '0' );\n";


  }


}


void VHDLGen::gen_sub_node(  Node * CNode )
{
 

  
  
 
}



void VHDLGen::gen_mul_node(  Node * CNode )
{
 
 Edge *l_edge, *r_edge, *out_edge;

  
  l_edge = c_dag->edge_vec[ CNode->in_edges[0] ];
  r_edge = c_dag->edge_vec[ CNode->in_edges[1] ];
  out_edge = c_dag->edge_vec[ CNode->out_edges.back() ];
  
  add_internal_signal( out_edge );

  int bw_a = (edge_bwdata[l_edge])->total_bw;
  int bw_b = (edge_bwdata[r_edge])->total_bw;

  int bw_out  = (edge_bwdata[out_edge])->total_bw;


  int comp_out_bw = bw_a + bw_b;

  stringstream comp_name;
  comp_name << "mul_" << bw_a << "x" << bw_b;

  string outtemp_sig_name( "tmp_" + CNode->node_name );
  //outtemp_sig_name << "tmp_" << CNode->node_name;

  sig_dec << "\tsignal " << outtemp_sig_name << " : ";

  sig_dec << "std_logic_vector( " << comp_out_bw << " - 1 downto 0 ) := ( others => '0' );\n";
  
  struct_code << endl << "-- Mul Node  " << endl;


  struct_code << CNode->node_name << ": " << comp_name.str() << endl;

  struct_code << "port map ( " << endl;

  struct_code << "a => " << signal_names[ l_edge ] << ","<< endl;
  struct_code << "b => " << signal_names[ r_edge ] << ","<< endl;

  struct_code << "o => " << outtemp_sig_name << endl;

 
  struct_code << ");\n\n";

  struct_code << signal_names[ out_edge ] << " <= " << outtemp_sig_name;
  

  adjust_signal_bw( comp_out_bw , bw_out , CNode->node_name );
  
 
  struct_code << ";\n\n";
  
  comp_table[ comp_name.str() ] = new COMP_TYPE( bw_a , bw_b , false , comp_out_bw , MUL_COMP );  //comp_data;

  
  
 
}

void VHDLGen::gen_const_node(  Node * CNode )
{
 

  
  
 
}

void VHDLGen::gen_output_node(  Node * CNode )
{
 

  
  
 
}

void VHDLGen::gen_input_node(  Node * CNode )
{
 

  
  
 
}

void VHDLGen::gen_entity_sec()
{

  entity_code << "entity bitsize_test is " << endl << endl;


  entity_code << "\t port ( " << endl;

 
  for ( vector<Edge*>::iterator s_itr = input_signals.begin();
	s_itr != input_signals.end(); s_itr++ )
    {
     
      entity_code << signal_names[ (*s_itr) ] << " : in ";
      entity_code << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;
      entity_code << " - 1 downto 0  );" << endl;
    }

  for ( vector<Edge*>::iterator s_itr = output_signals.begin();
	s_itr != output_signals.end(); s_itr++ )
    {
     
      entity_code << signal_names[ (*s_itr) ] << " : out ";
      entity_code << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;
      entity_code << " - 1 downto 0  ));" << endl;
    }


    entity_code << endl << "end bitsize_test; " << endl;


}


void VHDLGen::gen_arch_sec()
{

  arch_code << "architecture bitsize_test_arch of bitsize_test is  " << endl;

  
 for ( vector<Edge*>::iterator s_itr = internal_signals.begin();
	s_itr != internal_signals.end(); s_itr++ )
    {
     
      sig_dec << "\tsignal " << signal_names[ (*s_itr) ] << " : ";
      sig_dec << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;

      sig_dec << " - 1 downto 0  ) := ( others => '0' );" << endl;

    }

 arch_code << sig_dec.str() << endl;

}


void VHDLGen::gen_struct_sec()
{

  struct_code << "begin" << endl << endl;

  do_vhdlgen();

  struct_code << "end bitsize_test_arch;" << endl;

}


void VHDLGen::gen_components()
{

  comp_code << "attribute syn_black_box : boolean;\n\n";

  COMP_TYPE *comp_data;
  for ( map< string , COMP_TYPE * >::iterator c_itr = comp_table.begin();
	c_itr != comp_table.end(); c_itr++ ){
 
    comp_data = (*c_itr).second;

    comp_code << "\t-- BS_GEN_CORE "; 

    comp_code << (*c_itr).first;

    if ( comp_data->clocked )
      comp_code << " REG";
    else
      comp_code << " NOREG";


    comp_code << "\ncomponent " << (*c_itr).first << endl;

   
    
    comp_code << "port ( " << endl;

    comp_code << "a: in std_logic_vector( " << comp_data->bw_a << " -1 downto 0 );" << endl;

    comp_code << "b: in std_logic_vector( " << comp_data->bw_b << " -1 downto 0 );" << endl;

    switch( comp_data->c_type ){

    case ADD_COMP : comp_code << "s: out std_logic_vector( " << comp_data->bw_c << " -1 downto 0 ));" << endl;break;
      
    case MUL_COMP :  comp_code << "o: out std_logic_vector( " << comp_data->bw_c << " -1 downto 0 ));" << endl;break;

    default:;

    }

    if ( comp_data->clocked )
      comp_code << "clk : in std_logic " << endl;

    //comp_code << ");" << endl;

     comp_code << "end component; \n\n";

     comp_code << "attribute syn_black_box of " << (*c_itr).first;

     comp_code << ": component is true;" << endl;
     
  }  

 

}


void VHDLGen::update_edges_bw( string bwfilename )
{

  //string bwfilename = "bitsize_data.dat";

  
  fstream bw_fs( bwfilename.c_str() , ios::in );

  INTERNAL_ASSERT_EXIT( bw_fs.is_open() , "Error Opening " << bwfilename );

  Edge *CEdge;

  string var_name,var_arithtype , var_type;

  unsigned int int_bw, frac_bw;

  while( bw_fs >> var_name >> var_arithtype >> var_type >> int_bw >> frac_bw ){
    
    CEdge = varnames_map[ var_name ];

    edge_bwdata[ CEdge ] = new BW_DATA( int_bw , frac_bw ); 

  }


}

void VHDLGen::gen_test_bench( ostream &os ){


  stringstream tb_top;
  stringstream tb_arch;
  stringstream tb_str;

  gen_tb_top( tb_top );

  gen_tb_arch( tb_arch );

  gen_tb_struct( tb_str );



  os << tb_top.str() << endl;

  os << tb_arch.str() << endl;

  os << tb_str.str() << endl;


}


void VHDLGen::gen_tb_top(stringstream &tb_top){


  tb_top << "LIBRARY ieee;\n";
  tb_top << "USE ieee.std_logic_1164.ALL;\n";
  tb_top << "USE IEEE.std_logic_unsigned.all;\n";
  tb_top << "USE ieee.std_logic_arith.ALL;\n"; 
  tb_top << "USE std.textio.ALL;\n"; 
 
 
  tb_top << "\n\nentity bitsize_tb is\n";
  tb_top << "\nend bitsize_tb;\n\n"; 


}


void VHDLGen::gen_tb_arch(stringstream &tb_arch){

  tb_arch << "architecture tb_arch of bitsize_tb is \n\n"; 
  

  tb_arch << "component bitsize_test\n";

  tb_arch << "port (\n";

  for ( vector<Edge*>::iterator s_itr = input_signals.begin();
	s_itr != input_signals.end(); s_itr++ )
    {

      tb_arch << signal_names[ (*s_itr) ] << " : in ";
      tb_arch << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;
      tb_arch << " - 1 downto 0  );" << endl;

    }
  
  for ( vector<Edge*>::iterator s_itr = output_signals.begin();
	s_itr != output_signals.end(); s_itr++ )
    {

      tb_arch << signal_names[ (*s_itr) ] << " : out ";
      tb_arch << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;
      tb_arch << " - 1 downto 0  )";

      if ( s_itr + 1 != output_signals.end() )
	tb_arch << ";";

	
	      
      tb_arch << endl;

    }


   tb_arch << ");\nend component; " << endl;


   tb_arch << "constant PERIOD : time := 100 ns;\n";

   tb_arch << "signal sys_clk : std_logic := '0';\n";


    for ( vector<Edge*>::iterator s_itr = input_signals.begin();
	s_itr != input_signals.end(); s_itr++ )
    {
     
      tb_arch << "\tsignal " << signal_names[ (*s_itr) ] << "_temp : ";
      tb_arch << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;

      tb_arch << " - 1 downto 0  ) := ( others => '0' );" << endl;

    }

      for ( vector<Edge*>::iterator s_itr = output_signals.begin();
	s_itr != output_signals.end(); s_itr++ )
    {
     
      tb_arch << "\tsignal " << signal_names[ (*s_itr) ] << "_temp : ";
      tb_arch << "std_logic_vector( " << (edge_bwdata[ (*s_itr) ])->total_bw;

      tb_arch << " - 1 downto 0  ) := ( others => '0' );" << endl;

    }
   

}


void VHDLGen::gen_tb_struct( stringstream &tb_str ){

  tb_str << "begin  -- tb_arch \n\n";

  tb_str << "sys_clk <= not sys_clk after PERIOD/2;\n";

  int no_of_inputs = input_signals.size();

  tb_str << "readin_proc: process(sys_clk)\n"; 

  for ( int i = 1 ; i < no_of_inputs + 1 ; i++ ){

    tb_str << "\tFILE f" << i << "\t  : TEXT OPEN read_mode IS \"input" << i << ".dat\";\n";
    tb_str << "\tVARIABLE in_buf" << i << "\t : LINE;\n";
    tb_str << "\tVARIABLE in_var" << i << "\t : natural;\n";

  }

  tb_str << "\n\nbegin\n\n";

  tb_str << "if falling_edge(sys_clk) and not endfile(f1) then \n\n";

  for ( int i = 1 ; i < no_of_inputs + 1 ; i++ ){

    tb_str << "\treadline( f" << i << ", in_buf"<< i <<");\n";

    tb_str << "\tread( in_buf" << i << ", in_var" << i << ");\n";

    tb_str << "\t" << signal_names[ input_signals[ i - 1 ] ] << "_temp <= ";

    tb_str << "conv_std_logic_vector( in_var" << i << " , ";
    tb_str << (edge_bwdata[ input_signals[ i - 1] ])->total_bw << " );\n";


   }

  tb_str << "end if;\n";

  tb_str << "end process readin_proc;\n";

  tb_str << "writein_proc: process(sys_clk)\n\n";

  int no_of_outputs = output_signals.size();

   for ( int i = 1 ; i < no_of_outputs + 1 ; i++ ){

    tb_str << "FILE out_f" << i << "\t  : TEXT OPEN write_mode IS \"output" << i << ".dat\";\n";
    tb_str << "VARIABLE out_buf" << i << "\t : LINE;\n";
    tb_str << "VARIABLE out_var" << i << "\t : natural;\n";

  }

   
   tb_str << "begin \nif rising_edge(sys_clk) then \n\n";

    for ( int i = 1 ; i < no_of_outputs + 1 ; i++ ){

      tb_str << "\tout_var" << i << " := ";
      
      tb_str << "conv_integer( " << signal_names[ output_signals[ i - 1 ] ] << "_temp );\n";

    tb_str << "\twrite( out_buf" << i << ", out_var" << i << ");\n";


    tb_str << "\twriteline( out_f" << i << ", out_buf"<< i <<");\n";

    
   }

  tb_str << "end if;\n";

  tb_str << "end process writein_proc;\n\n";

  
  tb_str << "tb_comp : bitsize_test \n";

  tb_str << "port map ( \n";

   for ( vector<Edge*>::iterator s_itr = input_signals.begin();
	s_itr != input_signals.end(); s_itr++ )
    {

      tb_str << signal_names[ (*s_itr) ] << " => ";
      tb_str << signal_names[ (*s_itr) ] << "_temp,\n";
    
    }
  
  for ( vector<Edge*>::iterator s_itr = output_signals.begin();
	s_itr != output_signals.end(); s_itr++ )
    {

      tb_str << signal_names[ (*s_itr) ] << " => ";
      tb_str << signal_names[ (*s_itr) ] << "_temp";

      if ( s_itr + 1 != output_signals.end() )
	tb_str << ",";
      
      tb_str << endl;
    

    }


  tb_str << ");\n";


  tb_str << "\nend tb_arch;\n";

 
 
}
