#include "bitsize_pass.h"


void PwrPassGlitch::MAT_G_Prof_Add_ng( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

  
  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);

  HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);

 

  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_ADD_NG( ";

  f_body << "max( " << var_l->int_bw << " + bw_" << edge_l->edge_name << " , ";
  f_body << var_r->int_bw << " + bw_" << edge_r->edge_name << " ) ";
  f_body << " , " << edge_l->data_log.acoef_1 << " , ";
  f_body << edge_r->data_log.acoef_1 << " );" << endl;

  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

  f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;

  PWR_nodes.push_back(edge_out->edge_name);

}


void PwrPassGlitch::MAT_G_Prof_Sub_ng( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

 

  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);

   HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);

  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_ADD_NG( ";

  f_body << "max( " << var_l->int_bw << " + bw_" << edge_l->edge_name << " , ";
  f_body << var_r->int_bw << " + bw_" << edge_r->edge_name << " ) ";
  f_body << " , " << edge_l->data_log.acoef_1 << " , ";
  f_body << edge_r->data_log.acoef_1 << " );" << endl;

  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

  f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;


  PWR_nodes.push_back(edge_out->edge_name);


}

void PwrPassGlitch::MAT_G_Prof_Mul_ng( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

 

  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);

   HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);

  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_MUL_NG( ";

  f_body << "max( " << var_l->int_bw << " + bw_" << edge_l->edge_name << " , ";
  f_body << var_r->int_bw << " + bw_" << edge_r->edge_name << " ) ";
  f_body << " , " << edge_l->data_log.acoef_1 << " , ";
  f_body << edge_r->data_log.acoef_1 << " );" << endl;


  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

  f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;

  PWR_nodes.push_back(edge_out->edge_name);


}

void PwrPassGlitch::MAT_G_Prof_Add( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

  
  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);

  HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);


  
  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_ADD( ";

  f_body << "G_" << edge_l->edge_name << " , " << "G_" << edge_r->edge_name;

  f_body  << " );" << endl;


  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

  f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;


  PWR_nodes.push_back(edge_out->edge_name);
 

}


void PwrPassGlitch::MAT_G_Prof_Sub( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

 

  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);
  HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);


 
  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_ADD( ";

  f_body << "G_" << edge_l->edge_name << " , " << "G_" << edge_r->edge_name;

  f_body  << " );" << endl;


  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

   f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;



  PWR_nodes.push_back(edge_out->edge_name);


}

void PwrPassGlitch::MAT_G_Prof_Mul( Edge* edge_l , Edge* edge_r , Edge* edge_out)
{

 

  HWfix* var_l = dynamic_cast<HWfix*>(edge_l->my_var);
  HWfix* var_r = dynamic_cast<HWfix*>(edge_r->my_var);
  

  HWfix* var_out = dynamic_cast<HWfix*>(edge_out->my_var);



  f_body << "[ PWR_" << edge_out->edge_name << " , G_" << edge_out->edge_name << " ] = ";

  f_body << " F_MUL( ";

  f_body << "G_" << edge_l->edge_name << " , " << "G_" << edge_r->edge_name;

  f_body  << " );" << endl;


  f_body << "G_" << edge_out->edge_name << " = bw_trunc( ";

  f_body << "G_" << edge_out->edge_name << " , ( ";
  f_body << var_out->int_bw << " + bw_" << edge_out->edge_name  << " ) );" << endl;

  PWR_nodes.push_back(edge_out->edge_name);

}


void PwrPassGlitch::pwr_cost_header(){



  h_body << "function [cost_value, cost_flag] = cost_func_pwrglitch( bw )" << endl;

  h_body << "global bw_out;"  << endl;

  h_body << "[no_of_bw, bw_out_ , bw_names, bw_type,  bw_set , bw_ranges ] = parameters();" << endl;

  h_body << "req_error = 2.^-bw_out;" << endl;

  

  int ctr = 1;
  int output_sigs = 0;
  for( map<Edge*,string>::iterator s_itr = signal_names.begin(); s_itr != signal_names.end(); s_itr++ )
    {

      if ( (*s_itr).first->edge_type != OUT ){
	h_body << "bw_" << (*s_itr).first->edge_name << " = bw( " << ctr++ << " );" << endl;
      }
      else{
	h_body << "bw_" << (*s_itr).first->edge_name << " = bw_out;" << endl;
	output_sigs++;
      }

    }
  signal_count = ctr - 1;

  h_body << "my_error = error_function( bw  , bw_out );" << endl;
  h_body << "if ( ( my_error  > req_error) )" << endl; 
  h_body << "cost_flag = 0;" << endl;
  h_body << "cost_value = 0;" << endl;
  h_body << "else" << endl;

}


void PwrPassGlitch::pwr_cost_footer(){


  foot_body << "cost_value = sum( [ ";


  for ( list<string>::iterator itr = PWR_nodes.begin(); itr != PWR_nodes.end() ; itr++ )
    {

      foot_body << "PWR_" << (*itr) << " ";
  
    }



  foot_body << "]);" << endl;

  
  foot_body << "cost_flag = 1;" << endl;
  foot_body << "end;" << endl;

 
}



void PwrPassGlitch::gen_parameters_func( ostream &os ){

  os << "function [no_of_bw, bw_out , bw_names, bw_type, bw_state , bw_ranges ]";

  vector<dag_index>::iterator e_itr;

 
  os << "= parameters" << endl;

  os << "no_of_bw = " << signal_count - output_signal_count << ";" << endl;

  
  
  os << "bw_out " << " =[ ";

 

  for( e_itr = c_dag->output_edges.begin() ; e_itr != c_dag->output_edges.end() ; e_itr++ )
    {

       os  <<  dynamic_cast< HWfix *>(c_dag->edge_vec[(*e_itr)]->my_var)->frac_bw << " ";
     
    }

  os << "];" << endl;

  stringstream ss_names, ss_ranges ,ss_state, ss_type;

  int ctr = 1;

    ss_names << "bw_names = { ";
    ss_ranges << "bw_ranges = [ ";
    
    ss_state << "bw_state = [";

    ss_type << "bw_type = { ";

     // Print IN and TMP var info

    init_name_maps();

  for( map<Edge*,string>::iterator s_itr = signal_names.begin(); s_itr != signal_names.end(); s_itr++  )
    {
      if ( (*s_itr).first->edge_type != OUT ){

      ss_names << " '" << (*s_itr).second <<  "' "; 
       
       ss_ranges << get_range_bw( (*s_itr).first ) << " ";

       ss_state << get_bw_state( (*s_itr).first );
       
       ss_type << " '" << get_var_type( (*s_itr).first ) <<  "' ";


      }
    }


    // Print OUT var info

   for( vector<dag_index>::iterator e_itr = c_dag->output_edges.begin() ; e_itr != c_dag->output_edges.end() ; e_itr++ )
    {

      //os  <<  dynamic_cast< HWfix *>(c_dag->edge_vec[(*e_itr)]->my_var)->frac_bw << " ";
      // os << signal_bwnames[ c_dag->edge_vec[(*e_itr)] ] <<  " = bw_out(" << bw_out_ctr++ << ");" << endl; 

      ss_names << " '" << signal_names[ c_dag->edge_vec[(*e_itr)] ] <<  "' ";
      
      ss_ranges << get_range_bw(  c_dag->edge_vec[(*e_itr)]  ) << " ";

      

      ss_state << get_bw_state(  c_dag->edge_vec[(*e_itr)] );
      
      ss_type << " '" << get_var_type( c_dag->edge_vec[(*e_itr)] ) <<  "' ";


    }

  ss_names << "};" << endl;

  ss_ranges << "];" << endl;

  ss_state << "];" << endl;

  ss_type << "};" << endl;
  

  os << ss_names.str();

  os << ss_type.str();

  os << ss_ranges.str();

  
  os << ss_state.str();


 
    

}
