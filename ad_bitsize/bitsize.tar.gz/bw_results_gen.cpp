#include "bw_results_gen.h"

BWResultsGen::BWResultsGen( DAG *_dag ):c_dag(_dag){}

void BWResultsGen::gen_bitsize_dat( ostream &os ){


  vector<dag_index>::iterator e_itr;

  Edge *CEdge;
  for( e_itr = c_dag->edges_to_analyse.begin() ;e_itr != c_dag->edges_to_analyse.end() ; e_itr++ ){

    CEdge = c_dag->edge_vec[(*e_itr)];

     if (  CEdge->edge_type != ECONSTANT ){

       if( c_dag->arith_type == FIXED ){
	  gen_fixed_data( CEdge , os );
	
       }
       else if ( c_dag->arith_type == FLOAT ){
	  gen_float_data( CEdge , os );

       }

     }

  }


  for( e_itr = c_dag->output_edges.begin() ;e_itr != c_dag->output_edges.end() ; e_itr++ ){

    CEdge = c_dag->edge_vec[(*e_itr)];

     if (  CEdge->edge_type != ECONSTANT ){

       if( c_dag->arith_type == FIXED ){
	  gen_fixed_data( CEdge , os );
	
       }
       else if ( c_dag->arith_type == FLOAT ){
	  gen_float_data( CEdge , os );

       }

     }

  }


}




void BWResultsGen::gen_fixed_data( Edge *CEdge , ostream &os ){


  HWfix *temp;

  if( temp = dynamic_cast<HWfix*>( CEdge->my_var ) ){

    os << temp->var_name << " : FIX : ";
    os << temp->int_bw << " : ";
    os << temp->frac_bw <<  " : ";
    os << temp->int_bw_state << " : ";
    os << temp->frac_bw_state << endl;
    

  }


}



void BWResultsGen::gen_float_data( Edge *CEdge , ostream &os ){

 HWfloat *temp;

  if( temp = dynamic_cast<HWfloat*>( CEdge->my_var ) ){

    os << temp->var_name << " : FLT : ";
    os << temp->exp_bw << " : ";
    os << temp->man_bw <<  " : ";
    os << temp->exp_bw_state << " : ";
    os << temp->man_bw_state << endl;
    

  }



}


