#ifndef _BITSIZE_CLASS_H
#define _BITSIZE_CLASS_H

#include <string>
class AreaModel;
class ErrorModel;
class RangeAnalysis;
class ErrorModel_Affine;
class ErrorModel_Affine2;
class CostFunction;
class CostFunctionPWR;
class DAG;

class BitSizePass;
class NodeSchedular;
class ASCBackend;
class ADDAG;
class OptBW_flt;
class OptBW_fx;
class PwrDataPass;
class PwrPassGlitch;


class ILPGenPass;
class VHDLGen;

class BWResultsGen;

#include "hwvar.h"
//#include "hwfloat.h"
#include "hwint.h"
#include "hwvector.h"

#include "varcollections.h"

#include "dag.h"

#include "node_sched.h"
#include "areamodel.h"
#include "errormodel.h"
#include "range_analysis.h"
#include "errormodel_affine.h"

#include "ad_dag.h"
#include "optbw.h"

#include "bw_results_gen.h"

enum OPMODE_TYPE { PARSING , PARSED };

enum DEBUGMODE_TYPE { OFF , L1 , L2 };


class bitsize{


public:

  enum RANGE_ANN_MODES { AFFINE_RANGE , INTERVAL_RANGE , SIM_RANGE , NOOPT_RANGE };

  enum PREC_ANN_MODES { AFFINE_PREC,  AFFINE_PREC2 , AD_PREC , NOOPT_PREC };
  
  enum BW_MODES { UNIFORM , NONUNIFORM };

  enum OPT_METRICS { AREA_OPT , POWER_OPT , POWER_OPT_GLITCH};

  bitsize( int argc , char *argv[] );


  void bitsize_main();

  //std::string system_name;

  int opt_mode;

  DAG *mydag;

  OPMODE_TYPE global_opmode;

  DEBUGMODE_TYPE global_dbgmode;

  bool execute_once;
  
  double get_area();
  void list_vars();
  void list_vars2();

  void test_var(HWvar *t);


  void start_parse();
  void end_parse();

  varcollections<HWvar *> varC;

 

  // System Global settings

  RANGE_ANN_MODES range_ann_mode;

  PREC_ANN_MODES prec_ann_mode;

  BW_MODES bw_mode;

  OPT_METRICS opt_metric;

  bool mat_code_gen;

  bool ad_err_func_only;


  int db_level;

  // BitSize Passes
  AreaModel *myarea;

  NodeSchedular *mynode_sched;

  RangeAnalysis *range_analysis;

  ErrorModel_Affine *errmodel_affine;
  ErrorModel_Affine2 *errmodel_affine2;

  ErrorModel *myerror;

  CostFunction *cost_func;

  ASCBackend *asc_backend;

  ADDAG *ad_dag;

  BitSizePass *bs_pass;

  OptBW_flt *opt_flt;
  OptBW_fx *opt_fx;

  // Power Passes
  PwrDataPass *pwr_opt_datapass;
  
  PwrPassGlitch *pwr_pass_glitch;

  CostFunctionPWR *cost_func_pwr;
  
  bool ilp_gen;

  int ilp_ub_val;

  ILPGenPass *ilp_pass;

  bool vhdl_gen;

  VHDLGen *vhdlgen_pass;

  BWResultsGen *result_gen;

  void list_edges();
  
  
private:


  void run_passes();

  void run_passes_2();


  void init_passes();

  void run_passes_pwr();

  void run_passes_pwr_glitch();

  void run_fixedpoint_error();

  void gen_mat_testcode_fix();

  void gen_ilp_code();

  void gen_vhdlcode();

  // Input argument passing
  void show_help();
  void setup_defaults();
  void parse_arguments( int argc , char *argv[] );


  bool do_bit_opt;

  string bwdata_file;

  //void propagate_error();

};



#endif
