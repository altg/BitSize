// Pass to derive error propagation model

// $Author: amag97 $
// $Id: errormodel_affine.h,v 1.3 2004/11/15 00:21:10 amag97 Exp $
// $Log: errormodel_affine.h,v $
// Revision 1.3  2004/11/15 00:21:10  amag97
// Seperate Cost function
//
// Revision 1.2  2004/11/12 19:05:24  amag97
// More fixes to affine erromodel
//
// Revision 1.1  2004/11/09 18:47:07  amag97
// Added affine based error model generation
//



#ifndef _ERRORMODEL_AFFINE_H
#define _ERRORMODEL_AFFINE_H

// #include <sstream>

// #include "dag.h"
// class Node;
// class Edge;



#include "bitsize_pass.h"


// #include <ostream>
// using namespace std;



#endif
