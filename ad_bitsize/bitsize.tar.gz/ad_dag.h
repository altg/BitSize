// $Author: amag97 $
// $Id: ad_dag.h,v 1.7 2004/12/31 18:42:00 amag97 Exp $

#ifndef _AD_DAG_H
#define _AD_DAG_H

#include "bitsize_pass.h"
// #include "dag.h"
// class Node;
// class Edge;

// class ADDAG{

  
// public:
//   ADDAG( DAG * , NodeSchedular * );

//   DAG* c_dag;
//   NodeSchedular *node_sched;

//   void ad_input_node( Node *CNode );
//   void ad_add_node( Node *CNode );
//   void ad_sub_node( Node *CNode );
//   void ad_mul_node( Node *CNode );
//   void ad_div_node( Node *CNode );
//   void ad_shiftl_node( Node *CNode );
//   void ad_shiftr_node( Node *CNode );

//   void ad_assign_node( Node *CNode );

//   void ad_const_node( Node *CNode );

//   void ad_output_node( Node *CNode );

//   double get_const_value( Edge *CEdge );

//   double get_abs_eterms( Edge *CEdge );

//   void show_ad_vecs();

//   void do_ad_analysis_node(dag_index node_num);
  
//   void do_ad_analysis();

//   void find_min_max( Edge *CEdge );

//   int ad_index;
 

//   bool stop_flag;

//   bool operator()();

//   double read_from_file();

//   fstream fs,d_out;

//   map<int , Edge* > ad_ndx_map;

//   int iter_count;

// };





#endif
