// $Author: amag97 $
// $Id: affine_range.h,v 1.3 2004/12/06 00:46:52 amag97 Exp $

#ifndef _RANGE_AFFINE_H
#define _RANGE_AFFINE_H

#include "range_analysis.h"





#endif
