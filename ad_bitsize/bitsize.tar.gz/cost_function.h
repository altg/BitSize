// Pass to derive cost function

// $Author: amag97 $
// $Id: cost_function.h,v 1.1 2004/11/15 00:21:11 amag97 Exp $
// $Log: cost_function.h,v $
// Revision 1.1  2004/11/15 00:21:11  amag97
// Seperate Cost function
//

#ifndef _COST_FUNCTION_H
#define _COST_FUNCTION_H

#include "dag.h"
class Node;
class Edge;



#endif
